-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 26, 2014 at 09:45 
-- Server version: 5.1.41
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `inventory_brg`
--

-- --------------------------------------------------------

--
-- Table structure for table `barang`
--

CREATE TABLE IF NOT EXISTS `barang` (
  `id_barang` int(11) NOT NULL AUTO_INCREMENT,
  `tgl_entri` date NOT NULL,
  `kode_barang` varchar(50) NOT NULL,
  `kd_katagori` int(11) NOT NULL,
  `nama_barang` varchar(100) NOT NULL,
  `kode_pembuat` int(11) NOT NULL,
  `tahun_buat` year(4) NOT NULL,
  `jumlah_barang` int(11) NOT NULL,
  PRIMARY KEY (`id_barang`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `barang`
--

INSERT INTO `barang` (`id_barang`, `tgl_entri`, `kode_barang`, `kd_katagori`, `nama_barang`, `kode_pembuat`, `tahun_buat`, `jumlah_barang`) VALUES
(15, '2014-02-13', 'AAA-222', 0, 'Kursi', 0, 2013, 0),
(8, '2013-01-17', 'AAA-111', 10, 'Asus', 9, 2009, 10),
(16, '2012-03-12', 'AAA-112', 12345, 'AC', 0, 2014, 3);

-- --------------------------------------------------------

--
-- Table structure for table `deskripsi_barang`
--

CREATE TABLE IF NOT EXISTS `deskripsi_barang` (
  `kode_deskripsi` int(11) NOT NULL AUTO_INCREMENT,
  `id_barang` int(11) NOT NULL,
  `gambar` text NOT NULL,
  `keterangan` text NOT NULL,
  PRIMARY KEY (`kode_deskripsi`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `deskripsi_barang`
--

INSERT INTO `deskripsi_barang` (`kode_deskripsi`, `id_barang`, `gambar`, `keterangan`) VALUES
(2, 4, 'android.PNG', ''),
(3, 4, 'ucapan-selamat-tahun-baru-2013.jpg', 'dsff'),
(4, 5, 'FACHRA MAULIDIANA ANGGIT.png', ''),
(5, 6, 'angry_birds___space-wallpaper-1680x1050.jpg', ''),
(6, 7, 'angry_birds_best_party-wallpaper-1920x1080.jpg', ''),
(7, 8, 'tree_shade-wallpaper-2048x1536.jpg', ''),
(10, 15, 'icon_aerodynamics.png', ''),
(11, 16, 'background-22.jpg', '');

-- --------------------------------------------------------

--
-- Table structure for table `karyawan`
--

CREATE TABLE IF NOT EXISTS `karyawan` (
  `kode_karyawan` int(11) NOT NULL AUTO_INCREMENT,
  `nama_karyawan` varchar(35) NOT NULL,
  `tgl_masuk` date NOT NULL,
  `alamat` text NOT NULL,
  `telepon` varchar(15) NOT NULL,
  `keterangan` text NOT NULL,
  PRIMARY KEY (`kode_karyawan`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `karyawan`
--

INSERT INTO `karyawan` (`kode_karyawan`, `nama_karyawan`, `tgl_masuk`, `alamat`, `telepon`, `keterangan`) VALUES
(7, 'Perdianto', '2013-01-18', 'Jl. Bumi Graha, RT02 RW02 - Banjaran', '087122676786', 'PNS'),
(9, 'Haris Somantri', '2013-01-21', 'Jl. Bukit Bungur, Blok Selasa', '081234567887', ''),
(18, 'Dadi Saeful', '2014-02-14', 'LANGENG', '08980764618', '');

-- --------------------------------------------------------

--
-- Table structure for table `katagori`
--

CREATE TABLE IF NOT EXISTS `katagori` (
  `kd_katagori` varchar(10) NOT NULL,
  `jenis_alat` varchar(30) NOT NULL,
  PRIMARY KEY (`kd_katagori`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `katagori`
--

INSERT INTO `katagori` (`kd_katagori`, `jenis_alat`) VALUES
('12345abcde', 'Besi'),
('12345abcdf', 'Kayu'),
('12345abcdg', 'Elektronik');

-- --------------------------------------------------------

--
-- Table structure for table `pembuat`
--

CREATE TABLE IF NOT EXISTS `pembuat` (
  `kode_pembuat` int(11) NOT NULL AUTO_INCREMENT,
  `nama_pembuat` varchar(35) NOT NULL,
  `alamat` text NOT NULL,
  `email` text NOT NULL,
  `keterangan` text NOT NULL,
  PRIMARY KEY (`kode_pembuat`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `pembuat`
--

INSERT INTO `pembuat` (`kode_pembuat`, `nama_pembuat`, `alamat`, `email`, `keterangan`) VALUES
(16, 'Perdianto Putra Ratmaja', 'Cisaar', 'perdianto@gamil.com', ''),
(18, 'Dadi Saeful', 'Langeng', 'dadis@ymail.com', 'Honorer');

-- --------------------------------------------------------

--
-- Table structure for table `pengelola`
--

CREATE TABLE IF NOT EXISTS `pengelola` (
  `kode_peng` int(11) NOT NULL AUTO_INCREMENT,
  `nama_peng` varchar(35) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`kode_peng`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `pengelola`
--

INSERT INTO `pengelola` (`kode_peng`, `nama_peng`, `username`, `password`) VALUES
(1, 'Rani Yuliani', 'rani_yuliani@rocketmail.com', '12345678'),
(2, 'Nia Pitaloka', 'nia_p@live.com', '87654321'),
(4, 'Perdianto', 'perdianto.27email@gmail.com', 'perdianto');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
